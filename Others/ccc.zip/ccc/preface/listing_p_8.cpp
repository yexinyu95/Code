int main() {
  int a = 42;
  int& a_ref = a;
  int b = 100;
  a_ref = b;
}
