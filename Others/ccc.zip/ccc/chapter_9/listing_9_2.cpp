﻿#include <cstdio>

struct BostonCorbett final {
  void shoot() {
    printf("What a God we have...God avenged Abraham Lincoln");
  }
};

//struct BostonCorbettJunior : BostonCorbett {}; // Bang!

int main() {
  //  BostonCorbettJunior junior;
}
