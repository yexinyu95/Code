int main() {
  int x = 0;
  42 == x; // Equality
  42 != x; // Inequality
  100 > x; // Greater than
  123 >= x; // Greater than or equal to
  -10 < x; // Less than
  -99 <= x; // Less than or equal to
}
