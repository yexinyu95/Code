﻿#include <cstdio>

int main() {
  int x{};
  ++x;
  42;
  printf("The %d True Morty\n", x);
}
